package com.ajikadev.playmusicapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.loader.content.CursorLoader;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
  private static final int REQUEST_PERMISSIONS_CODE = 123;
  private Button playButton, stopButton, pauseButton, nextButton, previousButton;
  private MediaPlayer mediaPlayer;
  private int currentSongIndex = 0;
  private String[] audioFilePaths;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    playButton = findViewById(R.id.btnPlay);
    stopButton = findViewById(R.id.btnStop);
    pauseButton = findViewById(R.id.btnPause);
    nextButton = findViewById(R.id.btnNext);
    previousButton = findViewById(R.id.btnPrevious);

    playButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        fetchAudioFiles();
        playSong();
      }
    });

    stopButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        stopSong();
      }
    });

    pauseButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        pauseSong();
      }
    });

    nextButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        playNextSong();
      }
    });

    previousButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        playPreviousSong();
      }
    });
  }

  private void fetchAudioFiles() {
    // Display a toast message indicating the button click
    Toast.makeText(getApplicationContext(), "Fetching audio files...", Toast.LENGTH_SHORT).show();

    // Define the projection to retrieve album names
    String[] projection = new String[]{
      MediaStore.Audio.AlbumColumns.ALBUM,
      MediaStore.Audio.Media.DATA
    };

    // Specify the content URI for audio media files
    Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

    // Create a cursor loader to query the media store for audio files
    CursorLoader cursorLoader = new CursorLoader(getApplicationContext(), uri, projection,
      null, null, null);

    // Load the cursor in the background
    Cursor cursor = cursorLoader.loadInBackground();

    // Check if the cursor is not null and move to the first entry
    if (cursor != null && cursor.moveToFirst()) {
      audioFilePaths = new String[cursor.getCount()];
      int i = 0;
      do {
        // Retrieve the audio file path from the cursor
        String audioFilePath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
        audioFilePaths[i++] = audioFilePath;

      } while (cursor.moveToNext());
      // Close the cursor when finished
      cursor.close();
    }
  }

  private void playSong() {
    if (mediaPlayer == null) {
      if (audioFilePaths != null && audioFilePaths.length > 0) {
        try {
          mediaPlayer = new MediaPlayer();
          mediaPlayer.setDataSource(audioFilePaths[currentSongIndex]);
          mediaPlayer.prepare();
          mediaPlayer.start();
          Toast.makeText(getApplicationContext(), "Playing: " + audioFilePaths[currentSongIndex], Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
          e.printStackTrace();
        }
      } else {
        Toast.makeText(getApplicationContext(), "No audio files found", Toast.LENGTH_SHORT).show();
      }
    } else {
      mediaPlayer.start();
    }
  }

  private void stopSong() {
    if (mediaPlayer != null) {
      mediaPlayer.stop();
      mediaPlayer.release();
      mediaPlayer = null;
    }
  }

  private void pauseSong() {
    if (mediaPlayer != null && mediaPlayer.isPlaying()) {
      mediaPlayer.pause();
    }
  }

  private void playNextSong() {
    if (mediaPlayer != null && currentSongIndex < audioFilePaths.length - 1) {
      stopSong();
      currentSongIndex++;
      playSong();
    } else {
      Toast.makeText(getApplicationContext(), "No next song available", Toast.LENGTH_SHORT).show();
    }
  }

  private void playPreviousSong() {
    if (mediaPlayer != null && currentSongIndex > 0) {
      stopSong();
      currentSongIndex--;
      playSong();
    } else {
      Toast.makeText(getApplicationContext(), "No previous song available", Toast.LENGTH_SHORT).show();
    }
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
    stopSong();
  }
}